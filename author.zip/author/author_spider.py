from scrapy import Field, Item, Request
from scrapy.spiders import CrawlSpider, Rule
import string


class CeaSpider(CrawlSpider):
    name = 'scopus'

    def start_requests(self):

        for i in list(string.ascii_lowercase):
            for j in list(string.ascii_lowercase):
                yield Request(f'https://www.scopus.com/results/authorNa'
                              f'mesList.uri?sort=count-f&src=al&sid=6155'
                              f'e1dd57c90c9a71c385a89ac6ee33&sot=al&sdt='
                              f'al&sl=43&s=AUTHLASTNAME%28{i}%29'
                              f'+AND+AUTHFIRST%28{j}%29&st1={i}&'
                              f'st2={j}&orcidId=&selectionPageSea'
                              f'rch=anl&reselectAuthor=false&activeFlag=tr'
                              f'ue&showDocument=false&resultsPerPage=20&of'
                              f'fset=1&jtp=false&currentPage=1&previousSelect'
                              f'ionCount=0&tooManySelections=false&previousResultCount=0&authSubject=LFSC&authSubject=HLSC&authSubject=PHSC&authSubject=SOSC&exactAuthorSearch=false&showFullList=false&authorPreferredName=&origin=searchauthorfreelookup&affiliationId=&txGid=6debe4f33a75af27576df78efaed21'
                              f'28\n',

                              callback=self.parse_search, dont_filter=True)

    def parse_search(self, response):
        if response.status == 302:
            yield response.request.replace(dont_filter=True)
        else:
            for author in response.css('.authorResultsNamesCol a::attr(href)').getall():
                yield response.follow(author, callback=self.parse_author)

    def parse_author(self, response):
        if response.status == 302:
            yield response.request.replace(dont_filter=True)
        else:
            hold = {
                'ID': response.url.split('=')[-1],
                'Name': response.css('.wordBreakWord::text').get().replace('\xa0', ' '),
                'Affiliation': response.css('#firstAffiliationInHistory::text'
                                            '').get().replace('\r', ''),  # Affiliation
                'Subject area': ' | '.join(
                    [i.replace(',', ' -') for i in response.css('#subjectAreaBadges .badges::text').getall()]),
                # Subject area
                'Documents by author': response.css('#authorDetailsDocumentsByAuthor .fontLarge::text').get(),
                # Documents by author
                'Total Citations': response.css('#totalCiteCount::text').get(),  # Total Citations
                'h-index': response.css('#authorDetailsHindex .fontLarge::text').get(),  # h-index
                'URL': response.url
            }
            yield response.follow(f'https://www.scopus.com/author/document/retrieval'
                                  f'.uri?authorId={response.url.split("=")[-1]}', meta=hold,
                                  callback=self.parse_doc_title)

    def parse_doc_title(self, response):
        if response.status == 302:
            yield response.request.replace(dont_filter=True)
        else:
            doctitle = [''.join(response.css(f'#resultDataRow{i}')[0]
                                .css('.docTitle ::text').getall()).strip()
                        for i in range(3)]

            response.meta.update({
                'Doc Title 1': doctitle[0],
                'Doc Title 2': doctitle[1],
                'Doc Title 3': doctitle[2]
            })
            for k in ['depth', 'download_timeout', 'download_slot', 'download_latency']:
                if k in response.meta:
                    del response.meta[k]

            yield response.meta
